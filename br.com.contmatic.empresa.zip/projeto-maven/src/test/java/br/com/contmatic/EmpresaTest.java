package br.com.contmatic;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import br.com.contmatic.empresa.Empresa;

public class EmpresaTest {

	@Test
	public void nao_deve_aceitar_cnpj_nulo() {
		final Empresa empresa = new Empresa();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			empresa.setCnpj(null);
		});
	}
	
	@Test
	public void nao_deve_aceitar_cnpj_maior_que_11_caracteres() {
		final Empresa empresa = new Empresa();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			empresa.setCnpj("123456789012345");
		});
		
	}
	
	@Test
	public void nao_deve_aceitar_cnpj_menor_que_11_caracteres() {
		final Empresa empresa = new Empresa();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			empresa.setCnpj("1234567890");
		});
		
	}
	
	@Test
	public void nao_deve_aceitar_letras_no_cnpj() {
		final Empresa empresa = new Empresa();
		Assertions.assertThrows(IllegalArgumentException.class, () ->{
			empresa.setCnpj("QWERTYUIOPASDF");
		});
	
	}
	
	@Test
	public void nao_deve_aceitar_todos_os_digitos_iguais() {
		final Empresa empresa = new Empresa();
		Assertions.assertThrows(IllegalStateException.class, () ->{
			empresa.setCnpj("11111111111");
		});
	}
	

}
