package br.com.contmatic.empresa;

public class Empresa {

	private String cnpj;

	public String getCnpj() {
		return cnpj;
	}
	
	public void setCnpj(String cnpj) {
		if (cnpj == null) {
			throw new IllegalArgumentException("O CNPJ da Empresa não pode ser nulo");
		}
		if(cnpj.length()>=12) {
			throw new IllegalArgumentException("O CNPJ da Empresa não pode ser maior que 11 caracteres");
		}
		if(cnpj.length()<=10) {
			throw new IllegalArgumentException("O CNPJ da Empresa não pode ser menor que 11 caracteres");
		}
		if(cnpj.replaceAll("^[QWERTYUIOPASDFGHJKLÇZXCVBNM]", "") != null){
			throw new IllegalArgumentException("O CNPJ da Empresa não pode conter letras");
		}
}
}
